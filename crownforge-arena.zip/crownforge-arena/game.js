(() => {
'use strict';
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const W = 720, H = 1280;
let DPR = Math.min(window.devicePixelRatio || 1, 2);
function fitCanvas(){
  const r=canvas.getBoundingClientRect();
  canvas.width=Math.max(1,Math.floor(r.width*DPR));
  canvas.height=Math.max(1,Math.floor(r.height*DPR));
  ctx.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);
}
new ResizeObserver(fitCanvas).observe(canvas); fitCanvas();

const TAU=Math.PI*2;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const rand=(a,b)=>a+Math.random()*(b-a);
const teamColor=t=>t===1?'#50b9ff':'#ff5f6d';
const teamDark=t=>t===1?'#1678be':'#b82d48';

// Logical arena bounds
const ARENA={top:72,bottom:980,riverTop:492,riverBottom:580,bridgeL:215,bridgeR:505};

const CARDS={
  vanguard:{name:'Vanguard',cost:3,kind:'unit',hp:760,damage:105,speed:62,range:34,rate:.9,radius:24,role:'Melee',accent:'#4dc1ff',icon:'shield'},
  ranger:{name:'Ranger',cost:3,kind:'unit',hp:390,damage:92,speed:58,range:175,rate:1.0,radius:20,role:'Ranged',accent:'#e6b45a',icon:'bow'},
  stonekin:{name:'Stonekin',cost:5,kind:'unit',hp:1750,damage:155,speed:34,range:36,rate:1.35,radius:31,role:'Tower hunter',accent:'#9da7b5',icon:'rock',buildingFocus:true},
  ember:{name:'Ember Sage',cost:4,kind:'unit',hp:520,damage:118,speed:50,range:150,rate:1.15,radius:23,role:'Splash mage',accent:'#ff8a46',icon:'flame',splash:62},
  lancers:{name:'Lancers',cost:4,kind:'unit',hp:620,damage:96,speed:88,range:38,rate:.8,radius:21,role:'Fast duo',accent:'#7fe0c5',icon:'spear',count:2},
  wisps:{name:'Moon Wisps',cost:2,kind:'unit',hp:185,damage:52,speed:96,range:95,rate:.72,radius:15,role:'Swarm',accent:'#d18cff',icon:'wisp',count:3},
  guardian:{name:'Iron Guardian',cost:6,kind:'unit',hp:2280,damage:188,speed:30,range:40,rate:1.4,radius:34,role:'Heavy tank',accent:'#e1d26d',icon:'helm'},
  fireburst:{name:'Fireburst',cost:4,kind:'spell',damage:410,radius:100,role:'Area spell',accent:'#ff614d',icon:'meteor'}
};
const DECK=['vanguard','ranger','stonekin','ember','lancers','wisps','guardian','fireburst'];

let audioCtx=null, soundOn=true;
function audioReady(){if(!soundOn)return null; if(!audioCtx) audioCtx=new (window.AudioContext||window.webkitAudioContext)(); if(audioCtx.state==='suspended') audioCtx.resume(); return audioCtx;}
function tone(freq=440,dur=.08,type='sine',gain=.04,slide=0){
  const ac=audioReady(); if(!ac)return; const o=ac.createOscillator(),g=ac.createGain();
  o.type=type;o.frequency.setValueAtTime(freq,ac.currentTime);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(40,freq+slide),ac.currentTime+dur);
  g.gain.setValueAtTime(gain,ac.currentTime);g.gain.exponentialRampToValueAtTime(.0001,ac.currentTime+dur);o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+dur);
}
function sfx(name){
  if(name==='deploy'){tone(250,.09,'triangle',.035,160);setTimeout(()=>tone(420,.07,'triangle',.025,80),45)}
  if(name==='hit')tone(rand(100,150),.05,'square',.018,-45);
  if(name==='shot')tone(520,.045,'triangle',.015,-160);
  if(name==='boom'){tone(100,.24,'sawtooth',.055,-50);tone(70,.3,'square',.03,-20)}
  if(name==='tower'){tone(150,.35,'sawtooth',.05,-70);setTimeout(()=>tone(80,.4,'square',.03,-35),80)}
  if(name==='win'){[523,659,784,1046].forEach((f,i)=>setTimeout(()=>tone(f,.16,'triangle',.04,40),i*115))}
  if(name==='lose'){[392,330,262,196].forEach((f,i)=>setTimeout(()=>tone(f,.18,'sine',.035,-10),i*120))}
}

let game;
function makeTower(team,type,x,y){
  const king=type==='core';
  return {entity:'tower',team,type,x,y,radius:king?44:36,maxHp:king?3900:2250,hp:king?3900:2250,damage:king?118:96,range:king?210:195,rate:king?.78:.92,cd:rand(0,.4),dead:false,hitFlash:0};
}
function newGame(){
  game={
    state:'title',time:180,overtime:false,overtimeLeft:30,last:performance.now(),elapsed:0,
    playerElixir:5,enemyElixir:5,playerCrowns:0,enemyCrowns:0,
    selected:null,toast:'',toastT:0,shake:0,flash:0,
    towers:[
      makeTower(-1,'core',360,153),makeTower(-1,'side',177,244),makeTower(-1,'side',543,244),
      makeTower(1,'side',177,821),makeTower(1,'side',543,821),makeTower(1,'core',360,912)
    ],
    units:[],projectiles:[],particles:[],floaters:[],
    deck:DECK.slice(),hand:DECK.slice(0,4),queue:DECK.slice(4),enemyDeck:DECK.slice(),
    aiT:.8,cardPulse:0,matchResult:null
  };
}
newGame();

function playerTowers(){return game.towers.filter(t=>t.team===1)}
function enemyTowers(){return game.towers.filter(t=>t.team===-1)}

function spawnParticles(x,y,color,n=12,speed=100){
  for(let i=0;i<n;i++){const a=Math.random()*TAU,s=rand(speed*.35,speed);game.particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:rand(.25,.65),max:.65,size:rand(2,6),color});}
}
function floater(x,y,text,color='#fff'){game.floaters.push({x,y,text,color,life:.8});}

function spawnCard(key,team,x,y){
  const c=CARDS[key];
  if(c.kind==='spell') return castSpell(key,team,x,y);
  const n=c.count||1;
  for(let i=0;i<n;i++){
    const off=(i-(n-1)/2)*28;
    game.units.push({
      entity:'unit',id:Math.random().toString(36).slice(2),card:key,name:c.name,team,
      x:x+off+(n>1?rand(-7,7):0),y:y+(team===1?off*.15:-off*.15),
      hp:c.hp,maxHp:c.hp,damage:c.damage,speed:c.speed,range:c.range,rate:c.rate,radius:c.radius,
      buildingFocus:!!c.buildingFocus,splash:c.splash||0,cd:rand(0,.18),dead:false,hitFlash:0,bridgeX:x<360?ARENA.bridgeL:ARENA.bridgeR,
      anim:Math.random()*TAU
    });
  }
  spawnParticles(x,y,teamColor(team),14,90); sfx('deploy');
}
function castSpell(key,team,x,y){
  const c=CARDS[key];
  game.projectiles.push({spell:true,team,x:x+(team===1?0:0),y:team===1?1045:35,tx:x,ty:y,t:0,dur:.45,card:key,radius:c.radius,damage:c.damage,dead:false});
  tone(260,.14,'sawtooth',.03,300);
}

function cyclePlayerCard(key){
  const i=game.hand.indexOf(key); if(i<0)return;
  const used=game.hand.splice(i,1)[0];
  const next=game.queue.shift();
  game.hand.splice(i,0,next);
  game.queue.push(used);
}

function nearestEnemyUnit(u,max=Infinity){
  let best=null,bd=max;
  for(const e of game.units){if(e.dead||e.team===u.team)continue;const d=dist(u,e);if(d<bd){bd=d;best=e}}
  return best;
}
function nearestEnemyTower(u){
  let best=null,bd=Infinity;
  for(const t of game.towers){if(t.dead||t.team===u.team)continue;const d=dist(u,t);if(d<bd){bd=d;best=t}}
  return best;
}
function targetFor(u){
  if(!u.buildingFocus){const en=nearestEnemyUnit(u,135); if(en)return en;}
  return nearestEnemyTower(u)||nearestEnemyUnit(u);
}
function moveToward(u,tx,ty,dt){
  let dx=tx-u.x,dy=ty-u.y,d=Math.hypot(dx,dy)||1;
  const step=Math.min(d,u.speed*dt); u.x+=dx/d*step;u.y+=dy/d*step;
}
function navigate(u,target,dt){
  // Funnel units through one of two bridges while crossing the river.
  const ownSide=u.team===1 ? u.y>ARENA.riverBottom : u.y<ARENA.riverTop;
  const enemySide=u.team===1 ? u.y<ARENA.riverTop : u.y>ARENA.riverBottom;
  if(!enemySide){
    const bridgeY=u.team===1?ARENA.riverBottom-4:ARENA.riverTop+4;
    if(ownSide && Math.abs(u.x-u.bridgeX)>34){moveToward(u,u.bridgeX,bridgeY,dt);return;}
    if(u.y>=ARENA.riverTop-8&&u.y<=ARENA.riverBottom+8){moveToward(u,u.bridgeX,u.team===1?ARENA.riverTop-18:ARENA.riverBottom+18,dt);return;}
  }
  moveToward(u,target.x,target.y,dt);
}
function damageEntity(t,amt,fromTeam,splash=false){
  if(!t||t.dead)return;
  t.hp-=amt;t.hitFlash=.12;floater(t.x,t.y-t.radius-12,'-'+Math.round(amt),splash?'#ffd59a':'#fff');spawnParticles(t.x,t.y,splash?'#ff9b55':teamColor(fromTeam),splash?12:5,splash?130:70);sfx(splash?'boom':'hit');
  if(t.hp<=0){t.hp=0;t.dead=true;spawnParticles(t.x,t.y,'#ffd58a',32,180);game.shake=Math.max(game.shake,t.entity==='tower'?13:5);
    if(t.entity==='tower') towerDestroyed(t,fromTeam);
  }
}
function towerDestroyed(t,attacker){
  sfx('tower');
  if(t.type==='core'){
    if(attacker===1)game.playerCrowns=3;else game.enemyCrowns=3;
    endGame(attacker===1?'victory':'defeat');
  } else {
    if(attacker===1)game.playerCrowns++;else game.enemyCrowns++;
    game.toast=attacker===1?'Enemy tower shattered!':'Your tower fell!';game.toastT=1.6;
    if(game.overtime)endGame(attacker===1?'victory':'defeat');
  }
}
function shoot(from,to,damage,team,splash=0,color){
  const d=dist(from,to);game.projectiles.push({spell:false,team,x:from.x,y:from.y-8,tx:to.x,ty:to.y,target:to,t:0,dur:clamp(d/420,.12,.48),damage,splash,color:color||teamColor(team),dead:false});sfx('shot');
}
function updateUnits(dt){
  for(const u of game.units){
    if(u.dead)continue;u.anim+=dt*5;u.cd-=dt;u.hitFlash=Math.max(0,u.hitFlash-dt);
    const t=targetFor(u);if(!t)continue;
    const d=dist(u,t),reach=u.range+(t.radius||20);
    if(d<=reach){
      if(u.cd<=0){u.cd=u.rate;
        if(u.range>70)shoot(u,t,u.damage,u.team,u.splash,u.card==='ember'?'#ff9d55':u.card==='wisps'?'#d89cff':'#f8e2a0');
        else {damageEntity(t,u.damage,u.team,false); if(u.splash){for(const e of game.units){if(!e.dead&&e.team!==u.team&&e!==t&&dist(t,e)<u.splash)damageEntity(e,u.damage*.55,u.team,true)}}}
      }
    } else navigate(u,t,dt);
  }
  // soft separation
  for(let i=0;i<game.units.length;i++){const a=game.units[i];if(a.dead)continue;for(let j=i+1;j<game.units.length;j++){const b=game.units[j];if(b.dead||a.team!==b.team)continue;const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy),m=a.radius+b.radius;if(d>0&&d<m*.75){const p=(m*.75-d)*.06;a.x-=dx/d*p;b.x+=dx/d*p;a.y-=dy/d*p;b.y+=dy/d*p;}}}
  game.units=game.units.filter(u=>!u.dead||u.hp>0); // dead units removed immediately after effects
}
function updateTowers(dt){
  for(const t of game.towers){if(t.dead)continue;t.cd-=dt;t.hitFlash=Math.max(0,t.hitFlash-dt);if(t.cd>0)continue;
    let best=null,bd=t.range;for(const u of game.units){if(u.dead||u.team===t.team)continue;const d=dist(t,u);if(d<bd){bd=d;best=u}}
    if(best){t.cd=t.rate;shoot(t,best,t.damage,t.team,0,t.type==='core'?'#ffe07a':teamColor(t.team));}
  }
}
function updateProjectiles(dt){
  for(const p of game.projectiles){if(p.dead)continue;p.t+=dt;const k=clamp(p.t/p.dur,0,1);
    if(p.spell){p.cx=lerp(p.x,p.tx,k);p.cy=lerp(p.y,p.ty,k)-Math.sin(k*Math.PI)*180;}
    else {const target=p.target&&!p.target.dead?p.target:{x:p.tx,y:p.ty};p.tx=target.x;p.ty=target.y;p.cx=lerp(p.x,p.tx,k);p.cy=lerp(p.y,p.ty,k)-Math.sin(k*Math.PI)*28;}
    if(k>=1){p.dead=true;
      if(p.spell){
        const c=CARDS[p.card];spawnParticles(p.tx,p.ty,'#ff714f',42,210);game.shake=11;sfx('boom');
        for(const u of game.units){if(!u.dead&&u.team!==p.team&&Math.hypot(u.x-p.tx,u.y-p.ty)<=c.radius+u.radius)damageEntity(u,c.damage,p.team,true)}
        for(const t of game.towers){if(!t.dead&&t.team!==p.team&&Math.hypot(t.x-p.tx,t.y-p.ty)<=c.radius+t.radius)damageEntity(t,c.damage*.68,p.team,true)}
      } else if(p.target&&!p.target.dead){damageEntity(p.target,p.damage,p.team,false);if(p.splash){for(const u of game.units){if(!u.dead&&u.team!==p.team&&u!==p.target&&dist(p.target,u)<p.splash)damageEntity(u,p.damage*.55,p.team,true)}}}
    }
  }
  game.projectiles=game.projectiles.filter(p=>!p.dead);
}
function updateEffects(dt){
  for(const p of game.particles){p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.pow(.03,dt);p.vy*=Math.pow(.08,dt);p.vy+=30*dt}game.particles=game.particles.filter(p=>p.life>0);
  for(const f of game.floaters){f.life-=dt;f.y-=34*dt}game.floaters=game.floaters.filter(f=>f.life>0);
  game.toastT=Math.max(0,game.toastT-dt);game.shake=Math.max(0,game.shake-dt*30);game.flash=Math.max(0,game.flash-dt*2);
}
function aiAct(){
  const affordable=game.enemyDeck.filter(k=>CARDS[k].cost<=game.enemyElixir);
  if(!affordable.length)return;
  const key=affordable[Math.floor(Math.random()*affordable.length)],c=CARDS[key];
  game.enemyElixir-=c.cost;
  if(c.kind==='spell'){
    const candidates=game.units.filter(u=>!u.dead&&u.team===1);let x=360,y=720;if(candidates.length){const t=candidates[Math.floor(Math.random()*candidates.length)];x=t.x;y=t.y}
    else {const t=playerTowers().filter(t=>!t.dead)[Math.floor(Math.random()*playerTowers().filter(t=>!t.dead).length)];if(t){x=t.x;y=t.y}}
    castSpell(key,-1,x,y);
  } else {
    const lane=Math.random()<.5?0:1;const x=lane?rand(430,590):rand(130,290),y=rand(335,440);spawnCard(key,-1,x,y);
  }
}
function updateGame(dt){
  if(game.state!=='playing')return;
  game.elapsed+=dt;game.time-=dt;
  const double=game.time<=30||game.overtime;
  game.playerElixir=clamp(game.playerElixir+dt/(double?1.25:2.5),0,10);
  game.enemyElixir=clamp(game.enemyElixir+dt/(double?1.25:2.5),0,10);
  game.aiT-=dt;if(game.aiT<=0){game.aiT=rand(.75,1.45);aiAct()}
  updateUnits(dt);updateTowers(dt);updateProjectiles(dt);updateEffects(dt);
  if(game.time<=0){
    if(!game.overtime){
      if(game.playerCrowns!==game.enemyCrowns){endGame(game.playerCrowns>game.enemyCrowns?'victory':'defeat');}
      else {game.overtime=true;game.time=30;game.toast='SUDDEN DEATH — next tower wins!';game.toastT=2.5;game.flash=.8;}
    } else {
      const ph=playerTowers().reduce((s,t)=>s+t.hp,0),eh=enemyTowers().reduce((s,t)=>s+t.hp,0);
      endGame(ph===eh?'draw':ph>eh?'victory':'defeat');
    }
  }
}
function endGame(result){if(game.state==='over')return;game.state='over';game.matchResult=result;game.selected=null;result==='victory'?sfx('win'):result==='defeat'?sfx('lose'):tone(330,.3,'sine',.03,-40);}

function roundedRect(x,y,w,h,r,fill,stroke,lw=1){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lw;ctx.stroke()}}
function text(txt,x,y,size,color='#fff',align='center',weight=700){ctx.font=`${weight} ${size}px Inter,system-ui,sans-serif`;ctx.textAlign=align;ctx.textBaseline='middle';ctx.fillStyle=color;ctx.fillText(txt,x,y)}
function drawShadowEllipse(x,y,rx,ry,a=.25){ctx.fillStyle=`rgba(0,0,0,${a})`;ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,TAU);ctx.fill()}

function drawArena(){
  // stone border
  const grd=ctx.createLinearGradient(0,ARENA.top,0,ARENA.bottom);grd.addColorStop(0,'#406d48');grd.addColorStop(.48,'#4e8354');grd.addColorStop(.52,'#497b4e');grd.addColorStop(1,'#3e7147');ctx.fillStyle=grd;ctx.fillRect(0,ARENA.top,W,ARENA.bottom-ARENA.top);
  // grass checker / paths
  for(let y=ARENA.top;y<ARENA.bottom;y+=72)for(let x=0;x<W;x+=72){ctx.fillStyle=((x/72+y/72)&1)?'rgba(255,255,255,.018)':'rgba(0,0,0,.022)';ctx.fillRect(x,y,72,72)}
  // lanes
  ctx.strokeStyle='rgba(248,224,165,.13)';ctx.lineWidth=78;ctx.lineCap='round';
  [[177,250,177,815],[543,250,543,815]].forEach(p=>{ctx.beginPath();ctx.moveTo(p[0],p[1]);ctx.lineTo(p[2],p[3]);ctx.stroke()});
  // river
  const water=ctx.createLinearGradient(0,ARENA.riverTop,0,ARENA.riverBottom);water.addColorStop(0,'#45a8d0');water.addColorStop(.5,'#2b86b4');water.addColorStop(1,'#1c6895');ctx.fillStyle=water;ctx.fillRect(0,ARENA.riverTop,W,ARENA.riverBottom-ARENA.riverTop);
  ctx.strokeStyle='rgba(255,255,255,.16)';ctx.lineWidth=4;for(let x=-60;x<W;x+=95){ctx.beginPath();ctx.moveTo(x,ARENA.riverTop+20);ctx.quadraticCurveTo(x+25,ARENA.riverTop+10,x+55,ARENA.riverTop+20);ctx.stroke();ctx.beginPath();ctx.moveTo(x+30,ARENA.riverTop+58);ctx.quadraticCurveTo(x+55,ARENA.riverTop+48,x+85,ARENA.riverTop+58);ctx.stroke()}
  // bridges
  for(const bx of [ARENA.bridgeL,ARENA.bridgeR]){
    drawShadowEllipse(bx,536,57,49,.28);roundedRect(bx-50,ARENA.riverTop-8,100,(ARENA.riverBottom-ARENA.riverTop)+16,12,'#b7814d','#6b462c',5);
    ctx.strokeStyle='#e0b06e';ctx.lineWidth=4;for(let y=ARENA.riverTop+4;y<ARENA.riverBottom;y+=18){ctx.beginPath();ctx.moveTo(bx-44,y);ctx.lineTo(bx+44,y);ctx.stroke()}
    ctx.strokeStyle='#56371f';ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(bx-47,ARENA.riverTop);ctx.lineTo(bx-47,ARENA.riverBottom);ctx.stroke();ctx.beginPath();ctx.moveTo(bx+47,ARENA.riverTop);ctx.lineTo(bx+47,ARENA.riverBottom);ctx.stroke();
  }
  // decorations
  const trees=[[45,140],[675,155],[55,360],[665,365],[47,700],[675,710],[65,930],[650,925]];
  trees.forEach(([x,y],i)=>{drawShadowEllipse(x+2,y+12,25,10,.18);ctx.fillStyle='#6f4931';ctx.fillRect(x-6,y,12,27);ctx.fillStyle=i%2?'#2e7144':'#347d46';ctx.beginPath();ctx.arc(x,y-4,23,0,TAU);ctx.arc(x-14,y+5,16,0,TAU);ctx.arc(x+14,y+5,16,0,TAU);ctx.fill()});
  // side divider / deployment tint
  ctx.fillStyle='rgba(80,185,255,.025)';ctx.fillRect(0,ARENA.riverBottom,W,ARENA.bottom-ARENA.riverBottom);
  ctx.fillStyle='rgba(255,95,109,.025)';ctx.fillRect(0,ARENA.top,W,ARENA.riverTop-ARENA.top);
}
function drawTower(t){
  if(t.dead){
    drawShadowEllipse(t.x,t.y+20,t.radius+14,14,.28);ctx.fillStyle='#5d5b5e';for(let i=0;i<6;i++){ctx.save();ctx.translate(t.x+Math.cos(i*2.1)*rand(10,30),t.y+Math.sin(i*1.6)*rand(5,20));ctx.rotate(i);ctx.fillRect(-10,-6,20,12);ctx.restore()}return;
  }
  const team=t.team;drawShadowEllipse(t.x,t.y+24,t.radius+15,17,.3);
  ctx.save();if(t.hitFlash>0){ctx.shadowColor='#fff';ctx.shadowBlur=22}
  const base=ctx.createLinearGradient(t.x-t.radius,t.y,t.x+t.radius,t.y);base.addColorStop(0,teamDark(team));base.addColorStop(.5,teamColor(team));base.addColorStop(1,teamDark(team));
  // platform
  ctx.fillStyle='#675544';ctx.beginPath();ctx.ellipse(t.x,t.y+18,t.radius+16,19,0,0,TAU);ctx.fill();
  ctx.fillStyle=base;ctx.beginPath();ctx.roundRect(t.x-t.radius,t.y-t.radius*.8,t.radius*2,t.radius*1.6,10);ctx.fill();
  // battlements
  ctx.fillStyle=team===1?'#78ceff':'#ff8c96';const n=t.type==='core'?5:4;for(let i=0;i<n;i++){const xx=t.x-t.radius+5+i*((t.radius*2-10)/(n-1));ctx.fillRect(xx-7,t.y-t.radius*.94,14,15)}
  // roof/core jewel
  if(t.type==='core'){
    ctx.fillStyle='#27314c';ctx.beginPath();ctx.moveTo(t.x,t.y-t.radius-29);ctx.lineTo(t.x-33,t.y-t.radius+5);ctx.lineTo(t.x+33,t.y-t.radius+5);ctx.closePath();ctx.fill();
    ctx.fillStyle=teamColor(team);ctx.beginPath();ctx.arc(t.x,t.y-t.radius-5,9,0,TAU);ctx.fill();ctx.strokeStyle='#fff7cf';ctx.lineWidth=3;ctx.stroke();
  } else {
    ctx.fillStyle='#2b3040';ctx.beginPath();ctx.arc(t.x,t.y-t.radius*.18,10,0,TAU);ctx.fill();
  }
  ctx.restore();
  drawHpBar(t.x,t.y-t.radius-42,t.hp,t.maxHp,t.team,76);
}
function drawHpBar(x,y,hp,max,team,w=60){
  const pct=clamp(hp/max,0,1);roundedRect(x-w/2,y,w,9,5,'rgba(10,16,22,.65)');roundedRect(x-w/2+2,y+2,(w-4)*pct,5,3,pct<.3?'#ffcf4a':teamColor(team));
}
function drawUnitIcon(icon,x,y,s,accent='#fff',team=1){
  ctx.save();ctx.translate(x,y);ctx.strokeStyle='#172033';ctx.lineWidth=Math.max(2,s*.08);ctx.lineCap='round';ctx.lineJoin='round';
  const a=accent;
  if(icon==='shield'){ctx.fillStyle=a;ctx.beginPath();ctx.moveTo(0,-s*.55);ctx.lineTo(s*.42,-s*.32);ctx.lineTo(s*.32,s*.28);ctx.lineTo(0,s*.55);ctx.lineTo(-s*.32,s*.28);ctx.lineTo(-s*.42,-s*.32);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#fff4c0';ctx.fillRect(-s*.05,-s*.28,s*.1,s*.48)}
  if(icon==='bow'){ctx.strokeStyle=a;ctx.lineWidth=s*.14;ctx.beginPath();ctx.arc(-s*.12,0,s*.42,-1.25,1.25);ctx.stroke();ctx.strokeStyle='#f7e5c4';ctx.lineWidth=s*.06;ctx.beginPath();ctx.moveTo(s*.12,-s*.38);ctx.lineTo(s*.12,s*.38);ctx.stroke();ctx.beginPath();ctx.moveTo(-s*.42,0);ctx.lineTo(s*.38,0);ctx.stroke()}
  if(icon==='rock'){ctx.fillStyle=a;ctx.beginPath();ctx.moveTo(-s*.45,s*.3);ctx.lineTo(-s*.52,-s*.18);ctx.lineTo(-s*.2,-s*.5);ctx.lineTo(s*.26,-s*.45);ctx.lineTo(s*.5,-s*.05);ctx.lineTo(s*.32,s*.4);ctx.lineTo(-s*.1,s*.52);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#657180';ctx.beginPath();ctx.arc(-s*.14,-s*.1,s*.08,0,TAU);ctx.arc(s*.14,-s*.1,s*.08,0,TAU);ctx.fill()}
  if(icon==='flame'||icon==='meteor'){ctx.fillStyle=a;ctx.beginPath();ctx.moveTo(0,-s*.58);ctx.bezierCurveTo(s*.46,-s*.2,s*.5,s*.18,0,s*.56);ctx.bezierCurveTo(-s*.52,s*.18,-s*.38,-s*.12,-s*.14,-s*.34);ctx.bezierCurveTo(-s*.05,-s*.14,s*.02,-s*.08,0,-s*.58);ctx.fill();ctx.stroke();ctx.fillStyle='#ffe58e';ctx.beginPath();ctx.ellipse(0,s*.18,s*.15,s*.23,0,0,TAU);ctx.fill()}
  if(icon==='spear'){ctx.strokeStyle='#f5e0b5';ctx.lineWidth=s*.09;ctx.beginPath();ctx.moveTo(-s*.4,s*.45);ctx.lineTo(s*.34,-s*.45);ctx.stroke();ctx.fillStyle=a;ctx.beginPath();ctx.moveTo(s*.45,-s*.56);ctx.lineTo(s*.34,-s*.28);ctx.lineTo(s*.2,-s*.45);ctx.closePath();ctx.fill();ctx.stroke()}
  if(icon==='wisp'){ctx.fillStyle=a;ctx.beginPath();ctx.arc(0,0,s*.32,0,TAU);ctx.fill();ctx.shadowColor=a;ctx.shadowBlur=s*.45;ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle='#f5e8ff';ctx.lineWidth=s*.06;ctx.beginPath();ctx.moveTo(-s*.3,s*.18);ctx.quadraticCurveTo(0,s*.58,s*.3,s*.18);ctx.stroke()}
  if(icon==='helm'){ctx.fillStyle=a;ctx.beginPath();ctx.arc(0,-s*.05,s*.42,Math.PI,0);ctx.lineTo(s*.38,s*.4);ctx.lineTo(-s*.38,s*.4);ctx.closePath();ctx.fill();ctx.stroke();ctx.fillStyle='#293242';ctx.fillRect(-s*.26,-s*.04,s*.52,s*.1);ctx.fillRect(-s*.05,-s*.04,s*.1,s*.44)}
  ctx.restore();
}
function drawUnit(u){
  const c=CARDS[u.card];drawShadowEllipse(u.x,u.y+u.radius*.6,u.radius*.8,u.radius*.32,.25);ctx.save();ctx.translate(u.x,u.y+Math.sin(u.anim)*1.5);
  if(u.hitFlash>0){ctx.shadowColor='#fff';ctx.shadowBlur=18}
  // team ring
  ctx.strokeStyle=teamColor(u.team);ctx.lineWidth=4;ctx.beginPath();ctx.arc(0,0,u.radius+4,0,TAU);ctx.stroke();
  // body
  const g=ctx.createRadialGradient(-u.radius*.25,-u.radius*.3,2,0,0,u.radius);g.addColorStop(0,'#f2d4a8');g.addColorStop(.55,c.accent);g.addColorStop(1,'#202b42');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,u.radius,0,TAU);ctx.fill();ctx.strokeStyle='#172033';ctx.lineWidth=3;ctx.stroke();
  drawUnitIcon(c.icon,0,0,u.radius*.85,c.accent,u.team);ctx.restore();drawHpBar(u.x,u.y-u.radius-14,u.hp,u.maxHp,u.team,Math.max(42,u.radius*2));
}
function drawProjectile(p){
  const x=p.cx??p.x,y=p.cy??p.y;ctx.save();if(p.spell){ctx.fillStyle='#ff6b42';ctx.shadowColor='#ffad56';ctx.shadowBlur=30;ctx.beginPath();ctx.arc(x,y,15,0,TAU);ctx.fill();ctx.fillStyle='#ffe3a1';ctx.beginPath();ctx.arc(x-4,y-4,6,0,TAU);ctx.fill()}else{ctx.fillStyle=p.color;ctx.shadowColor=p.color;ctx.shadowBlur=16;ctx.beginPath();ctx.arc(x,y,6,0,TAU);ctx.fill()}ctx.restore();
}
function drawEffects(){
  for(const p of game.particles){ctx.globalAlpha=clamp(p.life/p.max,0,1);ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,TAU);ctx.fill()}ctx.globalAlpha=1;
  for(const f of game.floaters){ctx.globalAlpha=clamp(f.life/.8,0,1);text(f.text,f.x,f.y,18,f.color,'center',900)}ctx.globalAlpha=1;
}
function drawTopHud(){
  // top ribbon
  const grad=ctx.createLinearGradient(0,0,W,0);grad.addColorStop(0,'#181c31');grad.addColorStop(.5,'#252d4b');grad.addColorStop(1,'#181c31');ctx.fillStyle=grad;ctx.fillRect(0,0,W,72);
  text('CROWNFORGE',24,23,17,'#f4df9c','left',900);text('ARENA',24,48,13,'#9db5d7','left',800);
  const sec=Math.max(0,Math.ceil(game.time)),m=Math.floor(sec/60),s=String(sec%60).padStart(2,'0');
  roundedRect(290,12,140,48,16,'rgba(7,10,19,.66)','#5c6787',2);text(`${m}:${s}`,360,36,27,game.time<=30?'#ffd56b':'#fff', 'center',900);
  // score sigils
  text(`◆ ${game.enemyCrowns}`,584,27,20,'#ff8e98','center',900);text(`◆ ${game.playerCrowns}`,651,27,20,'#70caff','center',900);
  // sound
  roundedRect(675,40,34,26,10,'rgba(255,255,255,.08)');text(soundOn?'♪':'×',692,53,17,'#fff');
}
function drawBottomHud(){
  // bottom backdrop
  const g=ctx.createLinearGradient(0,970,0,H);g.addColorStop(0,'#1a2036');g.addColorStop(1,'#0c1020');ctx.fillStyle=g;ctx.fillRect(0,970,W,310);
  // elixir / energy
  text('ARCANA',31,1008,13,'#b7bfe2','left',900);
  roundedRect(104,992,552,30,15,'#15192b','#495270',2);
  const fillW=548*(game.playerElixir/10);if(fillW>2){const eg=ctx.createLinearGradient(108,0,656,0);eg.addColorStop(0,'#8757e8');eg.addColorStop(1,'#d65bff');roundedRect(108,996,fillW,22,11,eg)}
  for(let i=1;i<10;i++){ctx.fillStyle='rgba(255,255,255,.16)';ctx.fillRect(108+i*54.8,996,2,22)}
  text(game.playerElixir.toFixed(1),680,1007,16,'#ead6ff','right',900);
  // cards
  const cardW=135,cardH=194,gap=12,start=20,y=1050;
  game.hand.forEach((key,i)=>drawCard(key,start+i*(cardW+gap),y,cardW,cardH,game.selected===key));
  const next=game.queue[0];roundedRect(620,1040,78,104,18,'#13182a','#5a6480',2);text('NEXT',659,1056,10,'#94a0bf');drawUnitIcon(CARDS[next].icon,659,1095,26,CARDS[next].accent);text(CARDS[next].cost,659,1129,14,'#d99bff', 'center',900);
  // helper
  if(game.selected){const c=CARDS[game.selected];text(c.kind==='spell'?'Tap anywhere to cast':'Tap your side to deploy',360,1259,15,'#dce7ff','center',750)} else text('Select a card',360,1259,14,'#7f8aa8','center',700);
}
function drawCard(key,x,y,w,h,sel){
  const c=CARDS[key],enough=game.playerElixir+1e-4>=c.cost;
  ctx.save();if(sel){ctx.shadowColor=c.accent;ctx.shadowBlur=20}
  const bg=ctx.createLinearGradient(x,y,x,y+h);bg.addColorStop(0,'#34415f');bg.addColorStop(1,'#171e31');roundedRect(x,y-(sel?12:0),w,h,18,bg,sel?'#f7df87':'#65708d',sel?5:2);
  // portrait
  roundedRect(x+10,y+10-(sel?12:0),w-20,100,14,'#10182a');
  ctx.save();ctx.beginPath();ctx.roundRect(x+10,y+10-(sel?12:0),w-20,100,14);ctx.clip();const pg=ctx.createRadialGradient(x+w*.5,y+55,8,x+w*.5,y+55,85);pg.addColorStop(0,c.accent);pg.addColorStop(1,'#192039');ctx.fillStyle=pg;ctx.fillRect(x+10,y+10-(sel?12:0),w-20,100);for(let i=0;i<8;i++){ctx.globalAlpha=.12;ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(x+20+Math.random()*(w-40),y+20+Math.random()*80,rand(2,6),0,TAU);ctx.fill()}ctx.globalAlpha=1;drawUnitIcon(c.icon,x+w/2,y+57-(sel?12:0),44,c.accent);ctx.restore();
  // cost bubble
  ctx.fillStyle=enough?'#bd63ff':'#5a5065';ctx.beginPath();ctx.arc(x+19,y+18-(sel?12:0),20,0,TAU);ctx.fill();ctx.strokeStyle='#efe0ff';ctx.lineWidth=3;ctx.stroke();text(c.cost,x+19,y+18-(sel?12:0),18,'#fff','center',900);
  text(c.name,x+w/2,y+127-(sel?12:0),15,enough?'#fff':'#8d91a2','center',900);text(c.role,x+w/2,y+153-(sel?12:0),11,enough?'#bac5dd':'#707687','center',700);
  // readiness strip
  roundedRect(x+16,y+171-(sel?12:0),w-32,8,4,enough?c.accent:'#4b5262');ctx.restore();
}
function drawDeploymentOverlay(){
  if(!game.selected)return;const c=CARDS[game.selected];ctx.save();ctx.globalAlpha=.13;ctx.fillStyle=c.kind==='spell'?'#ffce69':'#66c7ff';if(c.kind==='spell')ctx.fillRect(0,ARENA.top,W,ARENA.bottom-ARENA.top);else ctx.fillRect(0,ARENA.riverBottom,W,ARENA.bottom-ARENA.riverBottom);ctx.restore();
  ctx.strokeStyle='rgba(255,255,255,.25)';ctx.setLineDash([12,14]);ctx.lineWidth=2;ctx.strokeRect(8,c.kind==='spell'?ARENA.top+8:ARENA.riverBottom+8,W-16,(c.kind==='spell'?ARENA.bottom-ARENA.top:ARENA.bottom-ARENA.riverBottom)-16);ctx.setLineDash([]);
}
function drawTitle(){
  // dim overlay
  ctx.fillStyle='rgba(5,8,17,.74)';ctx.fillRect(0,0,W,H);
  // crest
  ctx.save();ctx.translate(360,350);ctx.shadowColor='#68c7ff';ctx.shadowBlur=35;ctx.fillStyle='#213355';ctx.beginPath();ctx.arc(0,0,110,0,TAU);ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle='#eacb73';ctx.lineWidth=10;ctx.stroke();drawUnitIcon('shield',0,0,85,'#67c9ff');ctx.restore();
  text('CROWNFORGE',360,510,48,'#f6e2a4','center',950);text('ARENA',360,563,30,'#87ccff','center',900);text('An original real-time card battler',360,608,17,'#b6bfd5','center',650);
  roundedRect(140,690,440,110,30,'#2e8ed0','#a9e1ff',5);text('BATTLE',360,745,34,'#fff','center',950);
  roundedRect(175,832,370,78,22,'rgba(22,28,48,.82)','#536282',2);text('VS  FORGEKEEPER AI',360,871,18,'#d7def1','center',850);
  text('Tap a card → tap the arena → destroy the enemy core',360,960,15,'#a8b3cb','center',650);
  text('Touch + mouse • works on phone and PC',360,997,14,'#72809e','center',600);
  text('Original game • no Clash Royale art, names, or code used',360,1188,12,'#697590','center',600);
}
function drawOver(){
  ctx.fillStyle='rgba(6,8,17,.72)';ctx.fillRect(0,0,W,H);const win=game.matchResult==='victory',draw=game.matchResult==='draw';
  text(draw?'DRAW':win?'VICTORY':'DEFEAT',360,430,62,draw?'#d7dce8':win?'#f7da71':'#ff7b86','center',950);
  text(`◆ ${game.playerCrowns}  —  ${game.enemyCrowns} ◆`,360,510,28,'#fff','center',900);
  text(win?'The enemy forge is yours.':draw?'The arena stands even.':'The Forgekeeper held the arena.',360,570,18,'#bac4d9','center',650);
  roundedRect(145,690,430,105,28,win?'#318dcc':'#4d5571','#dce8ff',4);text('PLAY AGAIN',360,742,29,'#fff','center',950);
  text('Tip: ranged units behind a tank are hard to stop.',360,860,15,'#8e9bb7','center',650);
}
function render(){
  ctx.clearRect(0,0,W,H);ctx.save();if(game.shake>0)ctx.translate(rand(-game.shake,game.shake),rand(-game.shake,game.shake));
  drawArena();drawDeploymentOverlay();
  // towers behind units
  game.towers.filter(t=>t.y<540).forEach(drawTower);
  game.units.filter(u=>u.y<540).sort((a,b)=>a.y-b.y).forEach(drawUnit);
  game.towers.filter(t=>t.y>=540).forEach(drawTower);
  game.units.filter(u=>u.y>=540).sort((a,b)=>a.y-b.y).forEach(drawUnit);
  game.projectiles.forEach(drawProjectile);drawEffects();ctx.restore();drawTopHud();drawBottomHud();
  if(game.toastT>0){ctx.globalAlpha=clamp(game.toastT/.4,0,1);roundedRect(150,85,420,52,20,'rgba(15,20,37,.82)','#7c89aa',2);text(game.toast,360,111,18,'#fff','center',850);ctx.globalAlpha=1}
  if(game.flash>0){ctx.fillStyle=`rgba(255,255,255,${Math.min(.25,game.flash*.2)})`;ctx.fillRect(0,0,W,H)}
  if(game.state==='title')drawTitle();if(game.state==='over')drawOver();
}

function cardAt(x,y){
  const cardW=135,cardH=194,gap=12,start=20,cy=1050;
  for(let i=0;i<4;i++){const cx=start+i*(cardW+gap);if(x>=cx&&x<=cx+cardW&&y>=cy-20&&y<=cy+cardH)return game.hand[i]}
  return null;
}
function pointerPos(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width*W,y:(e.clientY-r.top)/r.height*H}}
function onPointer(e){e.preventDefault();audioReady();const p=pointerPos(e);
  if(p.x>665&&p.y<72){soundOn=!soundOn;if(soundOn)tone(620,.05,'sine',.02);return;}
  if(game.state==='title'){if(p.x>120&&p.x<600&&p.y>650&&p.y<840){game.state='playing';game.last=performance.now();game.toast='Battle started!';game.toastT=1.2;sfx('deploy')}return;}
  if(game.state==='over'){if(p.x>120&&p.x<600&&p.y>650&&p.y<830){newGame();game.state='playing';game.last=performance.now();sfx('deploy')}return;}
  if(game.state!=='playing')return;
  const ckey=cardAt(p.x,p.y);if(ckey){game.selected=game.selected===ckey?null:ckey;game.cardPulse=1;tone(520,.04,'triangle',.015,70);return;}
  if(!game.selected)return;const c=CARDS[game.selected];if(game.playerElixir+1e-4<c.cost){game.toast='Not enough Arcana';game.toastT=.8;tone(120,.08,'square',.02,-20);return;}
  if(p.y<ARENA.top||p.y>ARENA.bottom)return;
  if(c.kind==='unit'&&p.y<ARENA.riverBottom){game.toast='Deploy troops on your side';game.toastT=.8;return;}
  game.playerElixir-=c.cost;spawnCard(game.selected,1,clamp(p.x,85,W-85),clamp(p.y,c.kind==='spell'?ARENA.top+50:ARENA.riverBottom+35,ARENA.bottom-55));const used=game.selected;game.selected=null;cyclePlayerCard(used);
}
canvas.addEventListener('pointerdown',onPointer,{passive:false});
canvas.addEventListener('contextmenu',e=>e.preventDefault());

function loop(now){
  const dt=Math.min(.033,(now-game.last)/1000||0);game.last=now;updateGame(dt);render();requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
})();
