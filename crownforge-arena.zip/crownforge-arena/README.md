# Crownforge Arena

Original mobile-first real-time arena card battler.

## Controls
- Tap a card in your hand.
- Tap your half of the arena to deploy a troop.
- Fireburst may be cast anywhere.
- Destroy the enemy core tower to win.

## Features
- 8-card deck and rotating 4-card hand
- Arcana resource regeneration and double-rate endgame
- Two bridge pathfinding
- Melee, ranged, tank, swarm, splash and spell archetypes
- Three towers per side with autonomous targeting
- AI opponent
- 3-minute matches + sudden death overtime
- Touch and mouse controls
- Installable PWA / offline caching
- Procedural sound effects and original vector/canvas art

## Commercial/IP note
This game is mechanically inspired by the real-time lane/card-battler genre but does not include Clash Royale/Supercell assets, names, code, UI artwork, characters, card art, or maps.
