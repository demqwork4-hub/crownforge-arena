CROWNFORGE ARENA

Original browser/PWA arena card battler built for mobile and desktop.
No Clash Royale artwork, names, sound, code, maps, logos, characters, or UI assets are included.

Controls:
1. Tap a card.
2. Tap your half of the battlefield to deploy troops.
3. Spells can be cast anywhere.
4. Destroy enemy towers before time expires.

Commercial-use asset research:
- Kenney Tower Defense Kit — CC0
- Kenney UI Pack - Adventure — CC0
- Kenney Impact Sounds — CC0
Kenney states its asset-page game assets may be used commercially and attribution is not required.
These packs were evaluated as safe optional sources for future art expansion; this build uses original procedural/vector canvas art and synthesized sound, so it has no external runtime asset dependency.

Do not market this as an official Clash Royale product or use Supercell trademarks/artwork.
